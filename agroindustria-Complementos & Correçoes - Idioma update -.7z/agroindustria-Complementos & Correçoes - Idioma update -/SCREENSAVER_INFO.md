# 🎬 Tela de Screensaver - Marketing Inteligente

## O Que É?

Uma **tela de apresentação automática** que aparece quando o usuário fica inativo (não mexe no mouse, não digita, não clica). É como um "marketing automático" que mostra os benefícios do sistema enquanto o usuário está longe.

---

## 🎯 Como Funciona?

### 1️⃣ **Usuário Está Usando o Sistema**
- Dashboard, cadastros, relatórios
- Tudo funciona normalmente
- Timer de inatividade começou a contar

### 2️⃣ **Usuário Fica Inativo por 2 Minutos**
- Não clica em nada
- Não digita nada
- Não mexe o mouse

### 3️⃣ **Screensaver Aparece Automaticamente**
- Tela bonita e profissional
- Mostra benefícios do sistema
- Animações suaves
- Contagem regressiva de 30 segundos

### 4️⃣ **Usuário Volta**
- Clica em qualquer lugar
- Digita qualquer tecla
- Mexe o mouse
- Toca a tela (mobile)

### 5️⃣ **Sistema Detecta e Volta ao Dashboard**
- Imediatamente retorna ao dashboard
- Sem perder dados
- Sem perder sessão

---

## 📊 O Que o Screensaver Mostra?

### Informações Exibidas:
✅ **Logo e Título** - Identidade visual
✅ **6 Benefícios** - Em cards animados:
   - Controle Total
   - Sustentável
   - Eficiente
   - Rastreabilidade
   - Economia
   - Alertas Inteligentes

✅ **Estatísticas** - Dados do sistema:
   - 20+ Matérias-Primas
   - 7 Fornecedores
   - 25+ Movimentações
   - 100% Rastreável

✅ **Call-to-Action** - Botão para voltar
✅ **Indicadores** - Modo apresentação ativo
✅ **Contagem Regressiva** - Tempo até voltar automaticamente

---

## 🎨 Design e Animações

### Características Visuais:
- **Fundo Gradiente** - Azul profissional
- **Cards Animados** - Aparecem suavemente
- **Hover Effects** - Interatividade visual
- **Animações Fluidas** - Transições suaves
- **Responsivo** - Funciona em desktop e mobile

### Animações:
- 🎬 Logo flutua continuamente
- 📈 Cards deslizam para cima
- ✨ Fade in suave
- 🔄 Pulse nos indicadores

---

## ⏱️ Tempos Configuráveis

### Inatividade Necessária:
```
2 minutos (120 segundos) para ativar o screensaver
```

### Contagem Regressiva:
```
30 segundos antes de voltar automaticamente
```

### Onde Configurar:
Arquivo: `public/index.html` (linha 315)
```javascript
const INACTIVITY_TIMEOUT = 120000; // 2 minutos em milissegundos
```

---

## 🔄 Detecção de Atividade

### O Sistema Detecta:
✅ Cliques do mouse
✅ Digitação de teclado
✅ Movimento do mouse
✅ Scroll da página
✅ Toque na tela (mobile)

### Quando Detecta Atividade:
- ⏱️ Timer de inatividade reinicia
- 🔙 Se screensaver está ativo, volta ao dashboard
- ✅ Sessão continua ativa

---

## 📱 Responsividade

### Desktop:
- Layout completo com grid de 3 colunas
- Benefícios em cards grandes
- Estatísticas bem distribuídas

### Tablet:
- Grid adaptativo
- Tamanho de fonte reduzido
- Layout otimizado

### Mobile:
- Grid de 1 coluna
- Fonte menor
- Tudo scrollável
- Toque funciona perfeitamente

---

## 🎯 Benefícios Para o Negócio

### Marketing:
✅ Mostra benefícios do sistema automaticamente
✅ Reforça valor da solução
✅ Profissionalismo garantido
✅ Impressiona clientes/visitantes

### Funcionalidade:
✅ Economiza energia (tela de espera)
✅ Segurança (não deixa dados expostos)
✅ Experiência profissional
✅ Detecção inteligente de retorno

### Experiência:
✅ Transição suave
✅ Sem perder dados
✅ Retorno instantâneo
✅ Nenhuma confusão

---

## 🔧 Personalização

### Mudar Tempo de Inatividade:
1. Abra `public/index.html`
2. Procure por `INACTIVITY_TIMEOUT`
3. Mude o valor em milissegundos
   - 60000 = 1 minuto
   - 120000 = 2 minutos
   - 300000 = 5 minutos

### Mudar Benefícios Mostrados:
1. Abra `public/screensaver.html`
2. Procure pela seção `benefits-grid`
3. Edite os cards com suas informações

### Mudar Cores:
1. Abra `public/screensaver.html`
2. Procure pela seção `<style>`
3. Mude os valores de cor (ex: `#1a3a52`)

---

## 🚀 Como Testar

### Teste Local:
1. Acesse o dashboard
2. Não mexa em nada por 2 minutos
3. Screensaver aparece automaticamente
4. Clique em qualquer lugar
5. Volta ao dashboard

### Teste de Inatividade:
1. Abra o dashboard
2. Espere 2 minutos sem atividade
3. Screensaver deve aparecer

### Teste de Retorno:
1. Screensaver ativo
2. Clique em qualquer lugar
3. Deve voltar ao dashboard imediatamente

---

## 📋 Arquivo de Screensaver

**Localização:** `public/screensaver.html`

**Tamanho:** ~15 KB

**Dependências:** Nenhuma (HTML/CSS/JS puro)

**Compatibilidade:** Todos os navegadores modernos

---

## 🎬 Fluxo Completo

```
Dashboard (ativo)
    ↓ (2 minutos sem atividade)
Screensaver (apresentação)
    ↓ (clique/toque/tecla)
Dashboard (volta imediatamente)
```

---

## 💡 Dicas de Uso

1. **Para Apresentações:** Deixe o sistema rodando, o screensaver faz o marketing
2. **Para Segurança:** Evita que dados fiquem expostos
3. **Para Economia:** Tela de espera profissional
4. **Para Impressionar:** Mostra profissionalismo da solução

---

## 🎯 Próximos Passos

1. Descompacte o arquivo
2. Configure MySQL
3. Execute o script SQL
4. Inicie o servidor
5. Acesse o dashboard
6. Espere 2 minutos sem atividade
7. Veja o screensaver aparecer!

---

**Tela de Screensaver Pronta! 🎬✨**

Seu sistema agora faz marketing automático enquanto o usuário está longe!
